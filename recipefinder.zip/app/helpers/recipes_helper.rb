module RecipesHelper

end
